#!/bin/sh
$SORT | $DIFF $TEST_PATH/out -
