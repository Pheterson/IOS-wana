#!/bin/sh
$DIFF $TEST_PATH/out -
